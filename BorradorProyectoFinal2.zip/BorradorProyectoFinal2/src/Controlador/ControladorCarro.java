package Controlador;

import Modelo.Carro;
import java.util.ArrayList;

/**
 *ControladorCarro
 * 
 * @author Jorge
 * @version 1.0
 */

public class ControladorCarro {

    private static ControladorCarro instancia;
    private ArrayList<Carro> listaDeCarro;

    /**
     * En nuestro constructor creamos nuestro arraylist.
     * 
     */
    public ControladorCarro() {
        listaDeCarro = new ArrayList<Carro>();

    }
    
    /**
     * Este es un metodo para poder llamar a la Intancia que va a tener un dato ControladorCarro.
     * Si la intancia no tiene ningun valor entonces va a cambiar el valor de la instancia por ControladorCarro.
     * 
     * @return Retorna Instancia
     */
    public static ControladorCarro getInstancia() {
        if (instancia == null) {
           instancia = new ControladorCarro(); 
        }
        return instancia;
    }

    /**
     * Este metodo lo que hara esque el valor que es enviado del MenuAgregarCarro sera añadido al arraylist.
     * 
     * @param nuevoCarro n
     */
    public void agregarCarro(Carro nuevoCarro) {
        listaDeCarro.add(nuevoCarro);
    }

    /**
     *Este metodo servira para poder devolver el nuemro de espacios que tenemos en nuetro arraylist.
     * 
     * @return el tamaño que tiene nuestro arraylist
     */
    public int CantidadDeElementos() {
        return listaDeCarro.size();
    }

    /**
     * Este metodo lo usaremos para poder mostrar todos los datos que tenemos dentro de nuestro arraylist al metodo que lo llame.
     * 
     * @return Retornara los datos que hay dentro del arraylist.
     */ 
    public ArrayList<Carro> getListado() {
        return listaDeCarro;
    }

    /**
     *Este metodo lo usarmos para revisar si la placa que nos mandaron del metodo actualizar es la misma que tenemos
     * en nuestra placa en nuestro arraylist si esto es cierto el dato buscar tomara el valor que tiene
     * carro.
     * 
     * @param placa p
     * @return Retornaremos los nuevos datos de buscar.
     */
    public Carro verCarro(String placa) {
        Carro buscar = new Carro();
        for (Carro carro : listaDeCarro) {
            if (carro.getPlacaCarro().equals(placa)) {
                buscar = carro;
                break;
            }

        }
        return buscar;
    }

    /**
     * Lo que hara este metodo es que el dato que nos mandaron en este caso es productoCarro sea borrado de nuestro arraylist.
     * 
     * @param productoCarro pc 
     */
    public void borrarCarro(Carro productoCarro) {
        listaDeCarro.remove(productoCarro);
    }

    /**
     * Aca usamos el tema de polimorfismo ya que vamos a crear un metodo con el mismo nombre que el metodo de arriba
     * la diferencia esque aca vamos a recibir el dato que nos mandaron de la clase MenuEliminarCarro y este vamos
     * a compararlo con el dato que tenemos de placa en nuestro arraylist si este es verdadero vamos a asignarle a eliminar
     * el valor que tiene camioneta y esto vamos a sacarlo del arraylist.
     * 
     * @param placa p
     */
    public void borrarCarro(String placa) {
        Carro eliminar = new Carro();
        for (Carro carro : listaDeCarro) {
            if (carro.getPlacaCarro().equals(placa)) {
                eliminar = carro;
                listaDeCarro.remove(eliminar);
                break;
            }
        }
    }
    
    /**
     * Aca recibiremos dos datos de la clase MenuActualizarCarro y este lo que va a hacer es hagarar los datos que
     * teniamos en el arraylist y cambiarlos por los nuevos datos.
     * 
     * @param cAntiguo can
     * @param cActual cac
     */
    public void actualizarVehiculo(Carro cAntiguo, Carro cActual) {
        int indeceDelArray = listaDeCarro.indexOf(cAntiguo);
        listaDeCarro.set(indeceDelArray, cActual);
    }
}
