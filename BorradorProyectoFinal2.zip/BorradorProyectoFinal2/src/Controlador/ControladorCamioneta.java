package Controlador;

import Modelo.Camioneta;
import java.util.ArrayList;

/**
 *ControladorCamioneta
 * 
 * @author Jorge
 * @version 1.0
 */
public class ControladorCamioneta {

    private static ControladorCamioneta instancia;
    private ArrayList<Camioneta> listadoDeCamioneta;

    /**
     * En nuestro constructor creamos nuestro arraylist.
     * 
     */
    private ControladorCamioneta() {
        listadoDeCamioneta = new ArrayList<Camioneta>();
    }

    /**
     * Este es un metodo para poder llamar a la Intancia que va a tener un dato ControladorCamioneta.
     * Si la intancia no tiene ningun valor entonces va a cambiar el valor de la instancia por ControladorCamioneta.
     * 
     * @return Retornada la instancia.
     */
    public static ControladorCamioneta getInstancia() {
        if (instancia == null) {
            instancia = new ControladorCamioneta();
        }
        return instancia;
    }

    /**
     * Este metodo lo que hara esque el valor que es enviado del MenuAgregarCamioneta sera añadido al arraylist.
     * 
     * @param nuevaCamioneta camioneta 
     */
    public void agregarCamioneta(Camioneta nuevaCamioneta) {
        listadoDeCamioneta.add(nuevaCamioneta);
    }
    
    /**
     * Este metodo servira para poder devolver el nuemro de espacios que tenemos en nuetro arraylist.
     * 
     * @return el tamaño que tiene nuestro arraylist
     */
    public int CantidadDeElementos(){
        return listadoDeCamioneta.size();
    }
    
    /**
     * Este metodo lo usaremos para poder mostrar todos los datos que tenemos dentro de nuestro arraylist al metodo que lo llame.
     * 
     * @return Retornara los datos que hay dentro del arraylist.
    */
    public ArrayList<Camioneta> getListado() {
        return listadoDeCamioneta;
    }
    
    /**
     * Este metodo lo usarmos para revisar si la placa que nos mandaron del metodo actualizar es la misma que tenemos
     * en nuestra placa en nuestro arraylist si esto es cierto el dato buscar tomara el valor que tiene
     * camioneta.
     * 
     * @param placa placa
     * @return Retornaremos los nuevos datos de buscar.
     */
    public Camioneta buscarCarro(String placa) {
        Camioneta buscar = new Camioneta();
        for (Camioneta camioneta : listadoDeCamioneta) {
            if (camioneta.getPlacaCamioneta().equals(placa)) {
                buscar = camioneta;
                break;
            }

            break;
        }
        return buscar;
    }

    /**
     * Lo que hara este metodo es que el dato que nos mandaron en este caso es borrarCamioneta sea borrado de nuestro arraylist.
     * 
     * @param borrarCamioneta camioneta
     */
    public void borrarCamioneta(Camioneta borrarCamioneta) {
        listadoDeCamioneta.remove(borrarCamioneta);
    }

    /**
     * Aca usamos el tema de polimorfismo ya que vamos a crear un metodo con el mismo nombre que el metodo de arriba
     * la diferencia esque aca vamos a recibir el dato que nos mandaron de la clase MenuEliminarCamioneta y este vamos
     * a compararlo con el dato que tenemos de placa en nuestro arraylist si este es verdadero vamos a asignarle a eliminar
     * el valor que tiene camioneta y esto vamos a sacarlo del arraylist.
     * 
     * @param placa placa
     */
    public void borrarCamioneta(String placa) {
        Camioneta eliminar = new Camioneta();
        for (Camioneta camioneta : listadoDeCamioneta) {
            if (camioneta.getPlacaCamioneta().equals(placa)) {
                eliminar = camioneta;
                listadoDeCamioneta.remove(eliminar);

            }
        }
    }

    /**
     * Aca recibiremos dos datos de la clase MenuActualizarCamioneta y este lo que va a hacer es hagarar los datos que
     * teniamos en el arraylist y cambiarlos por los nuevos datos.
     * 
     * @param camAntiguo can
     * @param camActual cac
     */
    public void actualizarVehiculo(Camioneta camAntiguo, Camioneta camActual) {
        int indeceDelArray = listadoDeCamioneta.indexOf(camAntiguo);
        listadoDeCamioneta.set(indeceDelArray, camActual);
    }
}
