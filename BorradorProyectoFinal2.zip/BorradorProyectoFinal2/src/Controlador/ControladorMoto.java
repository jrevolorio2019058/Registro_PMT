package Controlador;

import Modelo.Moto;
import java.util.ArrayList;

/**
 *ControladorMoto
 * 
 * @author Jorge
 * @version 1.0
 */

public class ControladorMoto {

    private static ControladorMoto instancia;
    private ArrayList<Moto> listadoDeMoto;

    /**
     * En nuestro constructor creamos nuestro arraylist.
     * 
     */
    private ControladorMoto() {
        listadoDeMoto = new ArrayList<Moto>();
    }

    /**
     * Este es un metodo para poder llamar a la Intancia que va a tener un dato ControladorMoto.
     * Si la intancia no tiene ningun valor entonces va a cambiar el valor de la instancia por ControladorMoto.
     * 
     * @return Retornada la instancia.
     */
    public static ControladorMoto getInstancia() {
        if (instancia == null) {
            instancia = new ControladorMoto();
        }
        return instancia;
    }

    /**
     * Este metodo servira para poder devolver el nuemro de espacios que tenemos en nuetro arraylist.
     * 
     * @return el tamaño que tiene nuestro arraylist
     */
    public int CantidadDeElementos() {
        return listadoDeMoto.size();
    }

    /**
     * Este metodo lo que hara esque el valor que es enviado del MenuAgregarMoto sera añadido al arraylist.
     * 
     * @param nuevaMoto n
     */
    public void agregarMoto(Moto nuevaMoto) {
        listadoDeMoto.add(nuevaMoto);
    }

    /**
     * Este metodo lo usaremos para poder mostrar todos los datos que tenemos dentro de nuestro arraylist al metodo que lo llame.
     * 
     * @return Retornara los datos que hay dentro del arraylist.
     */
    public ArrayList<Moto> getListado() {
        return listadoDeMoto;
    }

    /**
     *Este metodo lo usarmos para revisar si la placa que nos mandaron del metodo actualizar es la misma que tenemos
     * en nuestra placa en nuestro arraylist si esto es cierto el dato buscar tomara el valor que tiene
     * moto.
     * 
     * @param placa p
     * @return Retornaremos los nuevos datos de buscar.
     */
    public Moto buscarMoto(String placa) {
        Moto buscar = new Moto();
        for (Moto moto : listadoDeMoto) {
            if (moto.getColorMoto().equals(placa)) {
                buscar = moto;
                break;
            }

        }
        return buscar;
    }

    /**
     * Lo que hara este metodo es que el dato que nos mandaron en este caso es borrarMoto sea borrado de nuestro arraylist.
     * 
     * @param eliminarMoto e
     */
    public void borrarMoto(Moto eliminarMoto) {
        listadoDeMoto.remove(eliminarMoto);
    }

    /**
     * Aca usamos el tema de polimorfismo ya que vamos a crear un metodo con el mismo nombre que el metodo de arriba
     * la diferencia esque aca vamos a recibir el dato que nos mandaron de la clase MenuEliminarMoto y este vamos
     * a compararlo con el dato que tenemos de placa en nuestro arraylist si este es verdadero vamos a asignarle a eliminar
     * el valor que tiene moto y esto vamos a sacarlo del arraylist.
     * 
     * @param placa p
     */
    public void borrarMoto(String placa) {
        Moto eliminar = new Moto();
        for (Moto moto : listadoDeMoto) {
            if (moto.getPlacaMoto().equals(placa)) {
                eliminar = moto;
                listadoDeMoto.remove(eliminar);

            }
        }
    }

    /**
     * Aca recibiremos dos datos de la clase MenuActualizarMoto y este lo que va a hacer es hagarar los datos que
     * teniamos en el arraylist y cambiarlos por los nuevos datos.
     * 
     * @param mAntiguo man
     * @param mActual mac
     */
    public void actualizarVehiculo(Moto mAntiguo, Moto mActual) {
        int indeceDelArray = listadoDeMoto.indexOf(mAntiguo);
        listadoDeMoto.set(indeceDelArray, mActual);
    }
}