package Controlador;
import Modelo.Usuario;
import java.util.ArrayList;

/**
 *ControladorUsuario
 * 
 * @author Jorge
 * @version 1.0
 */

public class ControladorUsuario {
    private static ControladorUsuario instancia;
    private ArrayList<Usuario> listaDeUsuario;

    /**
     * En nuestro constructor creamos nuestro arraylist.
     * 
     */
    public ControladorUsuario() {
        listaDeUsuario = new ArrayList<Usuario>();

    }

    /**
     * Este es un metodo para poder llamar a la Intancia que va a tener un dato ControladorUsuario.
     * Si la intancia no tiene ningun valor entonces va a cambiar el valor de la instancia por ControladorUsuario.
     * 
     * @return Retornada la instancia.
     */
    public static ControladorUsuario getInstancia() {
        if (instancia == null) {
           instancia = new ControladorUsuario(); 
        }
        return instancia;
    }

    /**
     * Este metodo lo que hara esque el valor que es enviado del MenuAgregarUsuario sera añadido al arraylist.
     * 
     * @param nuevoUsuario n
     */
    public void agregarUsuario(Usuario nuevoUsuario) {
        listaDeUsuario.add(nuevoUsuario);
    }

    /**
     * Este metodo servira para poder devolver el nuemro de espacios que tenemos en nuetro arraylist.
     * 
     * @return el tamaño que tiene nuestro arraylist
     */
    public int CantidadDeElementos() {
        return listaDeUsuario.size();
    }

    /**
     * Este metodo lo usaremos para poder mostrar todos los datos que tenemos dentro de nuestro arraylist al metodo que lo llame.
     * 
     * @return Retornara los datos que hay dentro del arraylist. 
     */
    public ArrayList<Usuario> getListado() {
        return listaDeUsuario;
    }

    /**
     * Este metodo lo usarmos para revisar si la placa que nos mandaron del metodo actualizar es la misma que tenemos
     * en nuestra placa en nuestro arraylist si esto es cierto el dato buscar tomara el valor que tiene
     * camioneta.
     * 
     * @param DPI d
     * @return Retornaremos los nuevos datos de buscar.
     */
    public Usuario verUsuario(String DPI) {
        Usuario buscar = new Usuario();
        for (Usuario usuario : listaDeUsuario) {
            if (usuario.getDPI().equals(DPI)) {
                buscar = usuario;
                break;
            }

        }
        return buscar;
    }
 
    /**
     * Aca recibiremos dos datos de la clase MenuActualizarUsuario y este lo que va a hacer es hagarar los datos que
     * teniamos en el arraylist y cambiarlos por los nuevos datos.
     * 
     * @param uAntiguo uan
     * @param uActual uac
     */
    public void actualizarUsuario(Usuario uAntiguo, Usuario uActual) {
        int indeceDelArray = listaDeUsuario.indexOf(uAntiguo);
        listaDeUsuario.set(indeceDelArray, uActual);
    }

    /**
     * Lo que hara este metodo es que el dato que nos mandaron en este caso es borrarUsuario sea borrado de nuestro arraylist.
     * 
     * @param productoUsuario p 
     */
    public void borrarUsuario(Usuario productoUsuario) {
        listaDeUsuario.remove(productoUsuario);
    }

    /**
     * Aca usamos el tema de polimorfismo ya que vamos a crear un metodo con el mismo nombre que el metodo de arriba
     * la diferencia esque aca vamos a recibir el dato que nos mandaron de la clase MenuEliminarUsuario y este vamos
     * a compararlo con el dato que tenemos de placa en nuestro arraylist si este es verdadero vamos a asignarle a eliminar
     * el valor que tiene camioneta y esto vamos a sacarlo del arraylist.
     * 
     * @param DPI d
     */
    public void borrarUsuario(String DPI) {
        Usuario eliminar = new Usuario();
        for (Usuario usuario : listaDeUsuario) {
            if (usuario.getDPI().equals(DPI)) {
                eliminar = usuario;
                listaDeUsuario.remove(eliminar);
                break;
            }
        }
    }
}
