/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package Vista;

import Controlador.ControladorUsuario;
import Modelo.Usuario;

/**
 *MenuEliminarUsuario
 * 
 * @author Jorge
 * @version 1.0
 * @see ControladorUsuario y Usuario.
 */

public class MenuEliminarUsuario extends javax.swing.JInternalFrame {

    /**
     * Instanciamos el controlador.
     * 
     */
    ControladorUsuario controladorUsuario = ControladorUsuario.getInstancia();
    
    /**
     * Crea nueva forma para MenuEliminarUsuario
     */
    public MenuEliminarUsuario() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jEliminar = new javax.swing.JLabel();
        jDPI1 = new javax.swing.JLabel();
        txtDPI1 = new javax.swing.JTextField();
        jConfirmacion = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jComprobacion = new javax.swing.JButton();
        jAviso = new javax.swing.JLabel();

        setClosable(true);

        jPanel1.setBackground(new java.awt.Color(255, 255, 102));
        jPanel1.setForeground(new java.awt.Color(255, 255, 102));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jEliminar.setBackground(new java.awt.Color(51, 0, 255));
        jEliminar.setFont(new java.awt.Font("Calibri", 0, 36)); // NOI18N
        jEliminar.setForeground(new java.awt.Color(0, 0, 255));
        jEliminar.setText("Eliminar Usuario");
        jPanel1.add(jEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 10, 250, 50));

        jDPI1.setFont(new java.awt.Font("Calibri", 0, 18)); // NOI18N
        jDPI1.setForeground(new java.awt.Color(255, 51, 51));
        jDPI1.setText("Ingrese el numero de DPI que desee eliminar:");
        jPanel1.add(jDPI1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 400, -1));
        jPanel1.add(txtDPI1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 80, 290, -1));

        jConfirmacion.setEditable(false);
        jConfirmacion.setFont(new java.awt.Font("Calibri", 0, 18)); // NOI18N
        jConfirmacion.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jPanel1.add(jConfirmacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 140, 570, 30));

        jButton1.setBackground(new java.awt.Color(51, 255, 204));
        jButton1.setFont(new java.awt.Font("Calibri", 0, 18)); // NOI18N
        jButton1.setText("Eliminar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 200, 120, 20));

        jComprobacion.setBackground(new java.awt.Color(51, 255, 204));
        jComprobacion.setFont(new java.awt.Font("Calibri", 0, 18)); // NOI18N
        jComprobacion.setText("Comprobacion DPI");
        jComprobacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComprobacionActionPerformed(evt);
            }
        });
        jPanel1.add(jComprobacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 200, 270, 20));

        jAviso.setFont(new java.awt.Font("Calibri", 1, 14)); // NOI18N
        jAviso.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jAviso.setText("Al ingresar su DPI, compruebe primero si su DPI es valida.");
        jPanel1.add(jAviso, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 50, 580, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 274, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Este boton lo que va a servir esque al recopilar el DPI que el usuario brindo lo va a mandar al controlador
     * y ahí lo va a comprobar si son iguales al que esta en el arraylist, si es así entonces elimina el
     * objeto.
     * 
     * @param evt 
     */
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String DPI = txtDPI1.getText();

        controladorUsuario.borrarUsuario(DPI);

        this.setVisible(false);

        txtDPI1.setText(" ");

        jConfirmacion.setText(" ");
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * Este boton es similar al boton anterior la diferencía esque al comparar si los datos son verdaderos lanzara el
     * mensaje de DPI valido sino lanzara el mensaje DPI Invalido.
     * 
     * @param evt 
     */
    private void jComprobacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComprobacionActionPerformed
        String DPI = txtDPI1.getText();

        for (Usuario uAntiguo : controladorUsuario.getListado()) {
            if (uAntiguo.getDPI().equals(DPI)) {
                jConfirmacion.setText("DPI Encontrada, Presione boton Eliminar");
            } else {
                jConfirmacion.setText("DPI Erroneo, Ingrese un DPI valido");
            }
        }

    }//GEN-LAST:event_jComprobacionActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jAviso;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jComprobacion;
    private javax.swing.JTextField jConfirmacion;
    private javax.swing.JLabel jDPI1;
    private javax.swing.JLabel jEliminar;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtDPI1;
    // End of variables declaration//GEN-END:variables
}
