package Vista;

/**
 *PantallaPrincipal
 * 
 * @author Jorge
 * @version 1.0
 */
public class PantallaPrincipal extends javax.swing.JFrame {

    /**
     * Crea nueva forma de PantallaPrincipal
     */
    public PantallaPrincipal() {
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelPrincipal = new javax.swing.JPanel();
        jPantallaPrincipal = new javax.swing.JMenuBar();
        jCarro = new javax.swing.JMenu();
        jAgregar = new javax.swing.JMenuItem();
        jReporte = new javax.swing.JMenuItem();
        jActualizar = new javax.swing.JMenuItem();
        jEliminar = new javax.swing.JMenuItem();
        jMoto = new javax.swing.JMenu();
        jAgregar1 = new javax.swing.JMenuItem();
        jReporte1 = new javax.swing.JMenuItem();
        jActualizar1 = new javax.swing.JMenuItem();
        jEliminar1 = new javax.swing.JMenuItem();
        jCamioneta = new javax.swing.JMenu();
        jAgregar2 = new javax.swing.JMenuItem();
        jReporte2 = new javax.swing.JMenuItem();
        jActualizar2 = new javax.swing.JMenuItem();
        jEliminar2 = new javax.swing.JMenuItem();
        jUsuario = new javax.swing.JMenu();
        jAgregar3 = new javax.swing.JMenuItem();
        jReporte3 = new javax.swing.JMenuItem();
        jActualizar3 = new javax.swing.JMenuItem();
        jEliminar3 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanelPrincipal.setBackground(new java.awt.Color(204, 255, 204));

        javax.swing.GroupLayout jPanelPrincipalLayout = new javax.swing.GroupLayout(jPanelPrincipal);
        jPanelPrincipal.setLayout(jPanelPrincipalLayout);
        jPanelPrincipalLayout.setHorizontalGroup(
            jPanelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 834, Short.MAX_VALUE)
        );
        jPanelPrincipalLayout.setVerticalGroup(
            jPanelPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 576, Short.MAX_VALUE)
        );

        jCarro.setText("Carro");

        jAgregar.setText("Agregar");
        jAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jAgregarActionPerformed(evt);
            }
        });
        jCarro.add(jAgregar);

        jReporte.setText("Reporte");
        jReporte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jReporteActionPerformed(evt);
            }
        });
        jCarro.add(jReporte);

        jActualizar.setText("Actualizar");
        jActualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jActualizarActionPerformed(evt);
            }
        });
        jCarro.add(jActualizar);

        jEliminar.setText("Eliminar");
        jEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jEliminarActionPerformed(evt);
            }
        });
        jCarro.add(jEliminar);

        jPantallaPrincipal.add(jCarro);

        jMoto.setText("Moto");

        jAgregar1.setText("Agregar");
        jAgregar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jAgregar1ActionPerformed(evt);
            }
        });
        jMoto.add(jAgregar1);

        jReporte1.setText("Reporte");
        jReporte1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jReporte1ActionPerformed(evt);
            }
        });
        jMoto.add(jReporte1);

        jActualizar1.setText("Actualizar");
        jActualizar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jActualizar1ActionPerformed(evt);
            }
        });
        jMoto.add(jActualizar1);

        jEliminar1.setText("Eliminar");
        jEliminar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jEliminar1ActionPerformed(evt);
            }
        });
        jMoto.add(jEliminar1);

        jPantallaPrincipal.add(jMoto);

        jCamioneta.setText("Camioneta");

        jAgregar2.setText("Agregar");
        jAgregar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jAgregar2ActionPerformed(evt);
            }
        });
        jCamioneta.add(jAgregar2);

        jReporte2.setText("Reporte");
        jReporte2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jReporte2ActionPerformed(evt);
            }
        });
        jCamioneta.add(jReporte2);

        jActualizar2.setText("Actualizar");
        jActualizar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jActualizar2ActionPerformed(evt);
            }
        });
        jCamioneta.add(jActualizar2);

        jEliminar2.setText("Eliminar");
        jEliminar2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jEliminar2ActionPerformed(evt);
            }
        });
        jCamioneta.add(jEliminar2);

        jPantallaPrincipal.add(jCamioneta);

        jUsuario.setText("Usuario");

        jAgregar3.setText("Agregar");
        jAgregar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jAgregar3ActionPerformed(evt);
            }
        });
        jUsuario.add(jAgregar3);

        jReporte3.setText("Reporte");
        jReporte3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jReporte3ActionPerformed(evt);
            }
        });
        jUsuario.add(jReporte3);

        jActualizar3.setText("Actualizar");
        jActualizar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jActualizar3ActionPerformed(evt);
            }
        });
        jUsuario.add(jActualizar3);

        jEliminar3.setText("Eliminar");
        jEliminar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jEliminar3ActionPerformed(evt);
            }
        });
        jUsuario.add(jEliminar3);

        jPantallaPrincipal.add(jUsuario);

        setJMenuBar(jPantallaPrincipal);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanelPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanelPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Este es nuestro Boton agregar de carro.
     * 
     * @param evt 
     */
    private void jAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jAgregarActionPerformed
        MenuAgregarCarro mAgregarCarro=new MenuAgregarCarro(); 
        jPanelPrincipal.add(mAgregarCarro);
        mAgregarCarro.setVisible(true);
    }//GEN-LAST:event_jAgregarActionPerformed

    /**
     * Este es nuestro Boton agregar de moto.
     * 
     * @param evt 
     */
    private void jAgregar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jAgregar1ActionPerformed
        MenuAgregarMoto mAgregarMoto=new MenuAgregarMoto(); 
        jPanelPrincipal.add(mAgregarMoto);
        mAgregarMoto.setVisible(true);
    }//GEN-LAST:event_jAgregar1ActionPerformed

    /**
     * Este es nuestro Boton agregar de camion.
     * 
     * @param evt 
     */
    private void jAgregar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jAgregar2ActionPerformed
        MenuAgregarCamioneta mAgregarCamioneta=new MenuAgregarCamioneta(); 
        jPanelPrincipal.add(mAgregarCamioneta);
        mAgregarCamioneta.setVisible(true);
    }//GEN-LAST:event_jAgregar2ActionPerformed

    /**
     * Este llama a nuestra clase MenuReporteCarro.
     * 
     * @param evt 
     */
    private void jReporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jReporteActionPerformed
        MenuReporteCarro mReporteCarro=new MenuReporteCarro(); 
        jPanelPrincipal.add(mReporteCarro);
        mReporteCarro.setVisible(true);
    }//GEN-LAST:event_jReporteActionPerformed

    /**
     * Este llama a nuestra clase MenuReporteMoto.
     * 
     * @param evt 
     */
    private void jReporte1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jReporte1ActionPerformed
        MenuReporteMoto mReporteMoto=new MenuReporteMoto(); 
        jPanelPrincipal.add(mReporteMoto);
        mReporteMoto.setVisible(true);   
    }//GEN-LAST:event_jReporte1ActionPerformed

    /**
     * Este llama a nuestra clase MenuReporteCamioneta.
     * 
     * @param evt 
     */
    private void jReporte2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jReporte2ActionPerformed
        MenuReporteCamioneta mReporteCamioneta=new MenuReporteCamioneta(); 
        jPanelPrincipal.add(mReporteCamioneta);
        mReporteCamioneta.setVisible(true);   
    }//GEN-LAST:event_jReporte2ActionPerformed

    /**
     * Este llama a nuestra clase MenuReporteUsuario.
     * 
     * @param evt 
     */
    private void jReporte3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jReporte3ActionPerformed
        MenuReporteUsuario mReporteUsuario=new MenuReporteUsuario(); 
        jPanelPrincipal.add(mReporteUsuario);
        mReporteUsuario.setVisible(true);
    }//GEN-LAST:event_jReporte3ActionPerformed

    /**
     * Este llama a nuestra clase MenuActualizarCarro.
     * 
     * @param evt 
     */
    private void jActualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jActualizarActionPerformed
        MenuActualizarCarro mActualizarCarro=new MenuActualizarCarro(); 
        jPanelPrincipal.add(mActualizarCarro);
        mActualizarCarro.setVisible(true); 
    }//GEN-LAST:event_jActualizarActionPerformed

    /**
     * Este llama a nuestra clase MenuActualizarMoto.
     * 
     * @param evt 
     */
    private void jActualizar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jActualizar1ActionPerformed
        MenuActualizarMoto mActualizarMoto=new MenuActualizarMoto(); 
        jPanelPrincipal.add(mActualizarMoto);
        mActualizarMoto.setVisible(true);
    }//GEN-LAST:event_jActualizar1ActionPerformed

    /**
     * Este llama a nuestra clase MenuActualizarMoto.
     * 
     * @param evt 
     */
    private void jActualizar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jActualizar2ActionPerformed
        MenuActualizarCamioneta mActualizarCamioneta=new MenuActualizarCamioneta(); 
        jPanelPrincipal.add(mActualizarCamioneta);
        mActualizarCamioneta.setVisible(true);
    }//GEN-LAST:event_jActualizar2ActionPerformed

    /**
     * Este llama a nuestra clase MenuEliminarCarro.
     * 
     * @param evt 
     */
    private void jEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jEliminarActionPerformed
        MenuEliminarCarro mEliminarCarro=new MenuEliminarCarro(); 
        jPanelPrincipal.add(mEliminarCarro);
        mEliminarCarro.setVisible(true);
    }//GEN-LAST:event_jEliminarActionPerformed

    /**
     * Este llama a nuestra clase MenuEliminarMoto.
     * 
     * @param evt 
     */
    private void jEliminar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jEliminar1ActionPerformed
        MenuEliminarMoto mEliminarMoto=new MenuEliminarMoto(); 
        jPanelPrincipal.add(mEliminarMoto);
        mEliminarMoto.setVisible(true);
    }//GEN-LAST:event_jEliminar1ActionPerformed

    /**
     * Este llama a nuestra clase MenuEliminarCamioneta.
     * 
     * @param evt 
     */
    private void jEliminar2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jEliminar2ActionPerformed
        MenuEliminarCamioneta mEliminarCamioneta=new MenuEliminarCamioneta(); 
        jPanelPrincipal.add(mEliminarCamioneta);
        mEliminarCamioneta.setVisible(true);
    }//GEN-LAST:event_jEliminar2ActionPerformed

    /**
     * Este llama a nuestra clase MenuAgregarUsuario.
     * 
     * @param evt 
     */
    private void jAgregar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jAgregar3ActionPerformed
        MenuAgregarUsuario mAgregarUsuario=new MenuAgregarUsuario(); 
        jPanelPrincipal.add(mAgregarUsuario);
        mAgregarUsuario.setVisible(true);
    }//GEN-LAST:event_jAgregar3ActionPerformed

    /**
     * Este llama a nuestra clase MenuActualizarUsuario.
     * 
     * @param evt 
     */
    private void jActualizar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jActualizar3ActionPerformed
        MenuActualizarUsuario mActualizarUsuario=new MenuActualizarUsuario(); 
        jPanelPrincipal.add(mActualizarUsuario);
        mActualizarUsuario.setVisible(true); 
    }//GEN-LAST:event_jActualizar3ActionPerformed

    /**
     *Este llama a nuestra clase MenuEliminarUsuario. 
     * 
     * @param evt 
     */
    private void jEliminar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jEliminar3ActionPerformed
        MenuEliminarUsuario mEliminarUsuario=new MenuEliminarUsuario(); 
        jPanelPrincipal.add(mEliminarUsuario);
        mEliminarUsuario.setVisible(true);
    }//GEN-LAST:event_jEliminar3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PantallaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PantallaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PantallaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PantallaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PantallaPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem jActualizar;
    private javax.swing.JMenuItem jActualizar1;
    private javax.swing.JMenuItem jActualizar2;
    private javax.swing.JMenuItem jActualizar3;
    private javax.swing.JMenuItem jAgregar;
    private javax.swing.JMenuItem jAgregar1;
    private javax.swing.JMenuItem jAgregar2;
    private javax.swing.JMenuItem jAgregar3;
    private javax.swing.JMenu jCamioneta;
    private javax.swing.JMenu jCarro;
    private javax.swing.JMenuItem jEliminar;
    private javax.swing.JMenuItem jEliminar1;
    private javax.swing.JMenuItem jEliminar2;
    private javax.swing.JMenuItem jEliminar3;
    private javax.swing.JMenu jMoto;
    private javax.swing.JPanel jPanelPrincipal;
    private javax.swing.JMenuBar jPantallaPrincipal;
    private javax.swing.JMenuItem jReporte;
    private javax.swing.JMenuItem jReporte1;
    private javax.swing.JMenuItem jReporte2;
    private javax.swing.JMenuItem jReporte3;
    private javax.swing.JMenu jUsuario;
    // End of variables declaration//GEN-END:variables
}
