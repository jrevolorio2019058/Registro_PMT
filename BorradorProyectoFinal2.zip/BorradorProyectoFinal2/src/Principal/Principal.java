package Principal;

import Vista.PantallaPrincipal;

public class Principal {
    public static void main(String args[]){
        
        PantallaPrincipal pPrincipal = new PantallaPrincipal();
        pPrincipal.setVisible(true);
        
    }
}
