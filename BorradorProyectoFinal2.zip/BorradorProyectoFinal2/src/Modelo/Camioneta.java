package Modelo;

/**
 * Camioneta
 * 
* @author Jorge
 * @version 1.0
 */
public class Camioneta{
    /**
     * En esta clase como es nuestro modelo vamos a declarar nuestra variables como privadas
     */
    private String modelo;
    private String marca;
    private String linea;
    private String color;
    private String placa;
    private int llantas;
    
    public Camioneta(String modelo,String marca,String linea,String color,String placa,int llantas){
        this.modelo = modelo;
        this.marca = marca;
        this.linea = linea;
        this.color = color;
        this.placa = placa;
        this.llantas = llantas;
    }
    
    /**
     * Este es nuestro constructor
     * 
     */
    public Camioneta(){
        
    }
    
    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos el modelo
     */
    public String getModeloCamioneta() {
        return modelo;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param modelo p
     */
    public void setModeloCamioneta(String modelo) {
        this.modelo = modelo;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Reroenamos la marca.
     */
    public String getMarcaCamioneta() {
        return marca;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param marca m
     */
    public void setMarcaCamioneta(String marca) {
        this.marca = marca;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos la linea.
     */
    public String getLineaCamioneta() {
        return linea;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param linea l
     */
    public void setLineaCamioneta(String linea) {
        this.linea = linea;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos el color.
     */
    public String getColorCamioneta() {
        return color;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param color c
     */
    public void setColorCamioneta(String color) {
        this.color = color;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos el numero de llantas.
     */
    public int getLlantasCamioneta() {
        return llantas;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param llantas ll
     */
    public void setLlantasCamioneta(int llantas) {
        this.llantas = llantas;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos el numero de llantas. 
     */
    public String getPlacaCamioneta() {
        return placa;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param placa p
     */
    public void setPlacaCamioneta(String placa) {
        this.placa = placa;
    }
}

