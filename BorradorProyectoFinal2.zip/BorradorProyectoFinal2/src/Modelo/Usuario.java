package Modelo;

/**
 * Usuario
 * 
* @author Jorge
 * @version 1.0
 */
public class Usuario {
    /**
     * En esta clase como es nuestro modelo vamos a declarar nuestra variables como privadas
     */
     private String DPI;
    private String nombre;
    private String apellido;
    private int edad;
    private String peso;
    private String estatura;
    
    public Usuario(String DPI,String nombre,String apellido,int edad,String peso,String estatura){
        this.DPI = DPI;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.peso = peso;
        this.estatura = estatura;
    }
   
    /**
     * Este es nuestro constructor
     * 
     */
    public Usuario(){
        
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos el DPI
     */
    public String getDPI() {
        return DPI;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param DPI d
     */
    public void setDPI(String DPI) {
        this.DPI = DPI;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos el nombre.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param nombre n
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos el apellido.
     */
    public String getApellido() {
        return apellido;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param apellido a
     */
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos la edad.
     */
    public int getEdad() {
        return edad;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param edad e
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos el peso.
     */
    public String getPeso() {
        return peso;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param peso p
     */
    public void setPeso(String peso) {
        this.peso = peso;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos la estatura.
     */
    public String getEstatura() {
        return estatura;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param estatura e
     */
    public void setEstatura(String estatura) {
        this.estatura = estatura;
    }
}
