package Modelo;

/**
 * Moto
 * 
* @author Jorge
 * @version 1.0
 */
public class Moto {
    /**
     * En esta clase como es nuestro modelo vamos a declarar nuestra variables como privadas
     */
    private String modelo;
    private String marca;
    private String linea;
    private String color;
    private String placa;
    private int llantas;
    
    public Moto(String modelo,String marca,String linea,String color,String placa,int llantas){
        this.modelo = modelo;
        this.marca = marca;
        this.linea = linea;
        this.color = color;
        this.placa = placa;
        this.llantas = llantas;
    }
    
     /**
     * Este es nuestro constructor
     * 
     */
    public Moto(){
        
    }
    
    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos el modelo
     */
    public String getModeloMoto() {
        return modelo;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param modelo m
     */
    public void setModeloMoto(String modelo) {
        this.modelo = modelo;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Reroenamos la marca.
     */
    public String getMarcaMoto() {
        return marca;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param marca m
     */
    public void setMarcaMoto(String marca) {
        this.marca = marca;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos la linea.
     */
    public String getLineaMoto() {
        return linea;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param linea l
     */
    public void setLineaMoto(String linea) {
        this.linea = linea;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos el color.
     */
    public String getColorMoto() {
        return color;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param color c
     */
    public void setColorMoto(String color) {
        this.color = color;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos el numero de llantas.
     */
    public int getLlantasMoto() {
        return llantas;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param llantas ll
     */
    public void setLlantasMoto(int llantas) {
        this.llantas = llantas;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos el numero de llantas. 
     */
    public String getPlacaMoto() {
        return placa;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param placa p
     */
    public void setPlacaMoto(String placa) {
        this.placa = placa;
    }
}
