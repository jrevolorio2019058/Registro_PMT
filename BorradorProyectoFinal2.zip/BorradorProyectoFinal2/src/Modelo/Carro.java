package Modelo;

/**
 * Carro
 * 
* @author Jorge
 * @version 1.0
 */
public class Carro {
    /**
     * En esta clase como es nuestro modelo vamos a declarar nuestra variables como privadas
     */
    private String modelo;
    private String marca;
    private String linea;
    private String color;
    private String placa;
    private int llantas;
    
    
    public Carro(String modelo,String marca,String linea,String color,String placa,int llantas){
        this.modelo = modelo;
        this.marca = marca;
        this.linea = linea;
        this.color = color;
        this.placa = placa;
        this.llantas = llantas;
    }
    
    /**
     * Este es nuestro constructor
     * 
     */
    public Carro(){
        
    }
    
    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos el modelo
     */
    public String getModeloCarro() {
        return modelo;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param modelo m
     */
    public void setModeloCarro(String modelo) {
        this.modelo = modelo;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Reroenamos la marca.
     */
    public String getMarcaCarro() {
        return marca;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param marca ma
     */
    public void setMarcaCarro(String marca) {
        this.marca = marca;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos la linea.
     */
    public String getLineaCarro() {
        return linea;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param linea l
     */
    public void setLineaCarro(String linea) {
        this.linea = linea;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos el color.
     */
    public String getColorCarro() {
        return color;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param color c
     */
    public void setColorCarro(String color) {
        this.color = color;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos el numero de llantas.
     */
    public int getLlantasCarro() {
        return llantas;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param llantas ll
     */
    public void setLlantasCarro(int llantas) {
        this.llantas = llantas;
    }

    /**
     * Como nuestras variables son privadas este metodo nos ayudara a que las variables puedan usarse
     * en otras clases
     * 
     * @return Retornamos el numero de llantas. 
     */
    public String getPlacaCarro() {
        return placa;
    }

    /**
     * Con este metodo podemos cambiar el valor de la variable.
     * 
     * @param placa p
     */
    public void setPlacaCarro(String placa) {
        this.placa = placa;
    }
}

